<?php require('koneksi.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>

<table>
  <tr>
    <td>Kode</td>
    <td>QR Code</td>
  </tr>

  <?php 
  $sql = "SELECT * FROM aset";
  $query = mysqli_query($conn, $sql);
  while($row = mysqli_fetch_array($query)) { ?> 
  <tr>
    <td><?= $row['barang'].$row['branch'].$row['bln']?></td>
    <td><img src="imgQRcode/<?= $row['qrCode']?>" alt="" style="width: 150px; height: 150px;">
  <?php } ?></td>
  </tr>
</table>

  <form action="qrcode.php" method="post">
    <label for="brg">Barang</label>
    <select name="brg" id="brg">
      <option value="MN">Monitor</option>
      <option value="TV">Televisi</option>
      <option value="HD">Handfree</option>
    </select>
    <!-- <input type="text" name="brg"> -->
    <label for="branch">Branch</label>
    <!-- <input type="text" name="branch"> -->
    <select name="branch" id="branch">
      <option value="DPK">Depok</option>
      <option value="SMR">Semarang</option>
      <option value="JK">Jakarta</option>
      <option value="BL">Bali</option>
    </select>
    <label for="bln">Bulan</label>
    <input type="date" name="bln">
    <button type="submit">Generate</button>
  </form>

</body>
</html>

