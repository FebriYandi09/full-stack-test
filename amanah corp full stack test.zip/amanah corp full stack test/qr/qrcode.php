<?php 
require('koneksi.php');
require('phpqrcode/qrlib.php');

// if (!empty($_GET['text'])) {
//   $text = $_GET['text'];

//   QRcode::png($text,false,QR_ECLEVEL_H,10,5);
// }

$sql = "SELECT * FROM aset";
$query = mysqli_query($conn, $sql);
$i = mysqli_fetch_array($query);

$kdawal=(int) substr($i['id'],3,3)+1;
if ($kdawal<10) {
  $kode='000'.$kdawal;
}else{
  $kode='00'.$kdawal;
}

$tempdir = "imgQRcode/"; //Nama folder tempat menyimpan file qrcode
            if (!file_exists($tempdir)) //Buat folder bername temp
            mkdir($tempdir);

$a = $_POST['brg'];
$b = $_POST['branch'];
$c = $_POST['bln'];
// $kode = (int) substr($a);
// $kode++;
$qr = $a.$b.$c."-".$kode++;

// var_dump($kode);die;
$d = $qr.".png";
$qual = 'H';
$ukuran = 6;
$padding = 1;
QRcode::png($qr,$tempdir.$d,$qual,$ukuran,$padding);

$sql = "INSERT INTO `aset` VALUES ('','$a','$b','$c','$d')";
$query = mysqli_query($conn, $sql);
// var_dump($query);

if ($query) {
  header('location:index.php');
}else{
  echo "gagal";
  die($conn->error);
}
?>