<?php 
$conn=mysqli_connect("localhost", "root", "", "fullstack_testqr");
?>